/**
 * This is an abstract class for objects that perform remote tests on CPUs.
 */
public abstract class CPU extends ComponentTester {
    //...
} // class CPU

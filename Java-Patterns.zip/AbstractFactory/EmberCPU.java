/**
 * This is a class for objects that perform remote tests on Ember
 * architecture CPUs.
 */
class EmberCPU extends CPU {
    //...
} // class EmberCPU

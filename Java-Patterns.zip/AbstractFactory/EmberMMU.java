/**
 * This is a class for objects that perform remote tests on Ember
 * architecture MMUs.
 */
public class EmberMMU extends MMU {
    //...
} // class EmbeMMU

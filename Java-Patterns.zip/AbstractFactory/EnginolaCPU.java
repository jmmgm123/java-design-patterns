/**
 * This is a class for objects that perform remote tests on Enginola
 * architecture CPUs.
 */
class EnginolaCPU extends CPU {
    //...
} // class EnginolaCPU

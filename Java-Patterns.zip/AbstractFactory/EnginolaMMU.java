/**
 * This is a class for objects that perform remote tests on Enginola
 * architecture MMUs.
 */
class EnginolaMMU extends MMU {
    //...
} // class EnginolaMMU

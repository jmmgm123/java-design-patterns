/**
 * This is an abstract class for objects that perform remote tests on MMUs.
 */
public abstract class MMU extends ComponentTester {
    //...
} // class MMU

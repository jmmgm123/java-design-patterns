import guiframework.AboutDialog;
import guiframework.MainFrame;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * This class is the top level frame for JCase.
 */
class MenuFrame extends MainFrame {
    private AboutDialog aboutDialog;
    private Panel drawingPanel;

    // The current controler element determines the mouse pointer being
    // used and the action taken for a mouse click.
    private DrawingController currentDrawingController;

    /**
     * constructor
     */
    MenuFrame() {
        super(ResourceManager.getString(ResourceManager.TITLE_MAIN));
        createMenus();
        addNotify();
        Dimension screenSize = getToolkit().getScreenSize();
        setSize(screenSize);
        drawingPanel = new Panel();
        drawingPanel.setBackground(Color.white);
        drawingPanel.setForeground(Color.black);
        add(drawingPanel, BorderLayout.CENTER);

        // Temporary code
        drawingPanel.addMouseListener(new TextController(drawingPanel));
    } // constructor()

    // build this frame's menus
    private void createMenus() {
        String caption;
        caption = ResourceManager.getString(ResourceManager.FILE);
        Menu fileMenu = new Menu(caption);
        fileMenu.add(new MenuItem("-"));
        caption = ResourceManager.getString(ResourceManager.EXIT);
        MenuItem exit = new MenuItem(caption);
        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                close();
            } // actionPerformed(ActionEvent)
          } );
        fileMenu.add(exit);

        caption = ResourceManager.getString(ResourceManager.ADD);
        Menu addMenu = new Menu(caption);
        caption = ResourceManager.getString(ResourceManager.TEXT_BOX);
        MenuItem textBox = new MenuItem(caption);
        addMenu.add(textBox);

        caption = ResourceManager.getString(ResourceManager.HELP);
        Menu help = new Menu(caption);
        caption = ResourceManager.getString(ResourceManager.ABOUT);
        MenuItem about = new MenuItem(caption);
        about.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                showAbout();
            } // actionPerformed(ActionEvent)
          } );
        help.add(about);

        MenuBar mb = new MenuBar();
        mb.add(fileMenu);
        mb.add(addMenu);
        mb.setHelpMenu(help);
        setMenuBar(mb);
    } // createMenus()

    /**
     * Show this frame's about dialog
     */
    void showAbout() {
        String title;
        title = ResourceManager.getString(ResourceManager.TITLE_ABOUT);
        String message;
        message = ResourceManager.getString(ResourceManager.ABOUT_MESSAGE);
        if (aboutDialog == null) {
            aboutDialog = new AboutDialog(this, title, message);
        } // if
        aboutDialog.show();
    } // showAbout()
} // class MenuFrame

/**
 * Instances of this class represent a column.
 */
class Column extends CompositeDocumentElement {
    //...
} // class Column

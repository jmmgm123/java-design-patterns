/**
 * Instances of this class represent a document.
 */
class Document extends CompositeDocumentElement {
    //...
} // class Document

/**
 * Instances of this class represent a Frame.
 */
class Frame extends CompositeDocumentElement {
    //...
} // class Frame

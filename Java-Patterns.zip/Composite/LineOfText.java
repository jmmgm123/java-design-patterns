/**
 * Instances of this class represent a line of text.
 */
class LineOfText extends CompositeDocumentElement {
    //...
} // class LineOfText

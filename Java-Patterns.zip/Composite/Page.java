/**
 * Instances of this class represent a page.
 */
class Page extends CompositeDocumentElement {
    //...
} // class Page

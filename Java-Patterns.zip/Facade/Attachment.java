/**
 * Instances of this class encapsulate message attachments
 */
class Attachment {
    /**
     * Constructor
     * @param content An object that supplies the content for this
     *                attachment.
     */
     Attachment(Object content) {
         //...
     } // Constructor(Object)
    //...
} // class Attachment

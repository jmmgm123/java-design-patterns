import java.util.Hashtable;

/**
 * Instances of this class encapsulate header information.
 */
class MessageHeader {
    /**
     * constructor
     * @param fields A Hashtable that contains the field values for this
     *               header.
     */
    MessageHeader(Hashtable fields) {
        //...
    } // constructor(Hashtable)
    //...
} // class MessageHeader

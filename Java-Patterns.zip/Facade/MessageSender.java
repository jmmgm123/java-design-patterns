/**
 * Instances of this class are responsible for sending e-mail
 * messages on their way.
 */
class MessageSender {
    //...
} // class MessageSender

/**
 * The contents of message bodies must either come from a String object or an
 * object the implements this interface.
 */
public interface RichText {
    //...
} // interface RichText

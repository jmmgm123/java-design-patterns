/**
 * Instances of this class encapsulate an algorithm and information
 * for signing an e-mail message.
 */
class Security {
    //...
} // class Security

/**
 * Instances of this class contain extrinsic attributes of ranges of
 * characters. 
 */
class CharacterContext extends DocumentContainer {
    //...
} // class CharacterContext

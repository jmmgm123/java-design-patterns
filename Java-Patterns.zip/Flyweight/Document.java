/**
 * Instances of this class represent a document.
 */
class Document extends DocumentContainer {
    //...
} // class Document

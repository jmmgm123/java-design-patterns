/**
 * All elements of a document belong to a subclass of this abstract class.
 */
abstract class DocumentElement {
    //...
} // class DocumentElement 

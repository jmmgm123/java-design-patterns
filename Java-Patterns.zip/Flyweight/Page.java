/**
 * Instances of this class represent a page.
 */
class Page extends DocumentContainer {
    //...
} // class Page

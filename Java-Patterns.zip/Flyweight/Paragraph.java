/**
 * Instances of this class represent a paragraph.
 */
class Paragraph extends DocumentContainer {
    //...
} // class Paragraph

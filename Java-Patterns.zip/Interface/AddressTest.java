import java.awt.*;
public class AddressTest extends Frame {
    public static void main(String[] argv) {
        new AddressTest().show();
    } // main(String[])

    AddressTest() {
        super("AddressPanel Test");
        add(new AddressPanel(), BorderLayout.CENTER);

        pack();

        setWindowListener( new WindowAdapter() {
            public void windowClosing(WindowEvent evt) {
            } // windowClosing(WindowEvent)
        } );
    } // Constructor()
} // class AddressTest

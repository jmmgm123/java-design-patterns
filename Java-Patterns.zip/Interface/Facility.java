class Facility {
    private String facilityName;
    private String costCenterID;

    //...

    /**
     * Return the facility name.
     */
    public String getFacilityName() {
        return facilityName;
    } // getFacilityName()

    /**
     * Return the costCenterID
     */
    public String getCostCenterID() {
        return costCenterID;
    } // getCostCenterID()
} // class Facility

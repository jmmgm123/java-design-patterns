/**
 * Instances of this class describe an inventory item
 */
public class InventoryItem {
    //...
} // class InventoryItem

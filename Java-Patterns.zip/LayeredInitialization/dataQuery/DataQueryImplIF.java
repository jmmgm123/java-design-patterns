package dataQuery;

/**
 * Classes the perform data queries on data bases implement this
 * interface.
 */
interface DataQueryImplIF {
    //...
} // interface DataQueryImplIF

package dataQuery;

/**
 * Class to perform queries using JDBC
 */
class JDBCQuery implements DataQueryImplIF {
    //...
} // class JDBCQuery

package dataQuery;

/**
 * Class to perform queries against an Oracle Database.
 */
class OracleQuery implements DataQueryImplIF {
    //...
} // class OracleQuery

package dataQuery;

/**
 * Class to perform queries against an Sybase Database.
 */
class SybaseQuery implements DataQueryImplIF {
    //...
} // class SybaseQuery

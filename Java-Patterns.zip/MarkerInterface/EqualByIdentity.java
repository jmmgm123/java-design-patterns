/**
 * Classes that implement this interface can be compared for equality by the
 * == operator
 */
public interface EqualByIdentity { }

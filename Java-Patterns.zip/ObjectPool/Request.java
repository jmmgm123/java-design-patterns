/**
 * Objects used to transmit requests to the database implment this
 * interface.
 */
interface Request {
    //...
} // interface Request

/**
 * Skeletal definition for a class that monitors security devices.
 */
public class SecurityMonitor {
    //...
    public void securityAlert(int device) {
        //...
    } // securityAlert(int)

    public void diagnosticAlert(int device) {
    } // diagnosticAlert(int)
} // SecurityMonitor


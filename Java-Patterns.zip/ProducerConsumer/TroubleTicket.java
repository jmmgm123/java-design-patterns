/**
 * Instances of this class represent a trouble ticket.
 */
public class TroubleTicket {
    //...
} // class TroubleTicket

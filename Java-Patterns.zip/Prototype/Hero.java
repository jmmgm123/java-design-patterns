/**
 * instances of this class are hero characters.
 */
public class Hero extends Character {
    private int bravery;
    //...

    public int getBravery() {
        return bravery;
    } // getBravery()

    public void setBravery(int bravery) {
        this.bravery = bravery;
    } // setBravery(int)
} // class Hero

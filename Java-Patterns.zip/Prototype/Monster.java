/**
 * instances of this class are monster characters.
 */
public class Monster extends Character {
    private int visciousness;
    //...

    public int getVisciousness() {
        return visciousness;
    } // getVisciousness()

    public void setVisciousness(int visciousness) {
        this.visciousness = visciousness;
    } // setVisciousness(int)
} // class Monster

class Parameters {
    //...
    boolean saveParam() {
        //...
        return true;
    } // saveParam()

    boolean applyParam() {
        //...
        return true;
    } // applyParam()

    boolean revertParam() {
        //...
        return true;
    } // revertParam()    
} // class Parameters

/**
 * Instances of this class represent a line of text.
 */
class Paragraph extends CompositeDocumentElement {
    //...
} // class Paragraph

/**
 * Instances of this class represent a table of contents in a document
 */
class TOC extends CompositeDocumentElement {
    //...
} // class TOC
